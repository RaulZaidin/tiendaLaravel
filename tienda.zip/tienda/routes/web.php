<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClothesController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('tienda.index');
// });

Route::get('/', [ClothesController::class, 'index'])->name('index');
Route::get('/clothescategory/{id}', [ClothesController::class, 'showCategories'])->name('clothes');
Route::get('/clothesgenre/{id}', [ClothesController::class, 'showGenre'])->name('clothes');

Route::get('clothesbusqueda', [ClothesController::class, 'showbusqueda'])->name('clothesbusqueda');

Route::get('/showProduct/{clothe}',[ClothesController::class, 'showProduct'])->name('showProduct');

Route::get('create', [ClothesController::class, 'create'])->name('create'); //formulario
Route::post('store', [ClothesController::class, 'store'])->name('store'); //sube archivo
