<?php $__env->startSection('content'); ?>

<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <!--<div class="ordenacion" style="width:15%">-->
                <!--    <select wire:model="orden" name="orden" id="orden" style="margin-bottom:50px" class="single-select2-no-search">-->
                <!--            <option value="selecciona">Sort by</option>-->
                <!--            <option value="Plane">Plane</option>-->
                <!--            <option value="Train">Train</option>-->
                <!--          </select>-->
                    
                <!--</div>-->
                <div class="row">
                     <?php $__currentLoopData = $clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clothe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        
                    <div class="col-lg-4 col-sm-6 mb-4" style="width:300px;margin-left:10px;padding:15px;box-shadow: 0px 0 30px rgb(25 25 25 / 8%);">
                        <!-- Portfolio item 1-->
                        <a href="<?php echo e(route('showProduct', $clothe)); ?>">
                        <div class="portfolio-item">
                            
                                <img class="img-fluid" src="../images/<?php echo e($clothe->images->file); ?>" alt="Product" style="height:250px;width:100%" />
                            
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading"><?php echo e($clothe->name); ?></div>
                                <div class="portfolio-caption-subheading text-muted"><?php echo e($clothe->price); ?>€</div>
                            </div>
                        </div>
                        </a>
                    </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($clothes->links("pagination::bootstrap-4")); ?>

                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tienda.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda/resources/views/tienda/clothescategory.blade.php ENDPATH**/ ?>