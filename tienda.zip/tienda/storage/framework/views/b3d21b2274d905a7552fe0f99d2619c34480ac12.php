<?php $__env->startSection('content'); ?>


<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    <section class="page-section" id="contact">
            <div class="container">
                <form id="Form" action="store" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6" style="margin-top:20px">
                            <input type="file" name="file" id="file"/>
                        </div>
                    </div>
                    
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase" id="submitButton" type="submit">Crear Reseña</button></div>
                </form>
            </div>
        </section>

                </div>
            </div>
        </section>
        
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('tienda.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda/resources/views/tienda/create.blade.php ENDPATH**/ ?>