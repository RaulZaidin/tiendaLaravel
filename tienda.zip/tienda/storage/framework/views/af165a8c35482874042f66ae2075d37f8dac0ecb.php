<?php $__env->startSection('content'); ?>

<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                     <?php $__currentLoopData = $clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clothe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php
                     $category = $clothe->idCategory;
                     
                     ?>
                     <?php if($category == $id): ?>
                        
                    <div class="col-lg-4 col-sm-6 mb-4" style="background-color:#f6f3e9 ;width:300px;margin-left:10px;padding:15px;">
                        <!-- Portfolio item 1-->
                        <a class="portfolio-link" data-bs-toggle="modal" href="#">
                        <div class="portfolio-item">
                            
                                <img class="img-fluid" src="../images/<?php echo e($clothe->images->file); ?>" alt="Product" style="height:250px;width:100%" />
                            
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading"><?php echo e($clothe->name); ?></div>
                                <div class="portfolio-caption-subheading text-muted"><?php echo e($clothe->price); ?>€</div>
                            </div>
                        </div>
                        </a>
                    </div>
                    <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tienda.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda/resources/views/tienda/clothes.blade.php ENDPATH**/ ?>