<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clothes', function (Blueprint $table) {
            $table->id();
            $table->string('name', 40);
            $table->unsignedBigInteger('idCategory');
            $table->unsignedBigInteger('idGenre');
            $table->unsignedBigInteger('idimage');
            $table->string('description', 100);
            $table->decimal('price');
            $table->foreign('idCategory')->references('id')->on('categories');
            $table->foreign('idGenre')->references('id')->on('gender');
            $table->foreign('idimage')->references('id')->on('images');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clothes');
    }
};
