<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Image;
use App\Models\Genre;
use App\Models\Category;

class Clothe extends Model
{
    use HasFactory;
    
    public function images(){
        return $this->hasOne(Image::class, 'id','idimage');
    }
    
    public function categories(){
        return $this->hasOne(Category::class, 'id', 'idCategory');
    }
    
    public function genre(){
        return $this->hasOne(Genre::class, 'id', 'idGenre');
    }
    protected $fillable = [
        'id',
        'idCategory',
        'idGenre'
    ];
    
}
