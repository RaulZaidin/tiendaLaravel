<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Clothe;
use App\Models\Image;
use App\Models\Category;


class ClothesController extends Controller
{

    //
    
    
    
    
    public function index()
    {
        return view('tienda.index');
    }
    public function showCategories($id){
        // $clothes = Clothe::all();//Problema porque coge todos los productos y hace mal la paginacion
        $clothes=Clothe::where("idCategory", "LIKE", "%$id%")->paginate(3);

        return view('tienda.clothescategory',['activePosts'=> 'active','clothes' => $clothes, 'subTitle'=> 'Clothes - Index']);
    }
    public function showGenre($id){
        $clothes=Clothe::where("idGenre", "LIKE", "%$id%")->paginate(3);
        return view('tienda.clothescategory',['activePosts'=> 'active','clothes' => $clothes, 'subTitle'=> 'Clothes - Index']);
    }
    
    public function showProduct(Clothe $clothe){
        return view('tienda.product',['clothe'=> $clothe]);
    }
    public function showbusqueda(Request $request){
        $busqueda = $request->busquedaproducto;
        
        $product = Clothe::orderBy("name");
        if ($busqueda) {
            $product->where("name", "LIKE", "%$busqueda%");
        }
        $clothes = $product->paginate(3);
        return view('tienda.clothesbusqueda',['activePosts'=> 'active','clothes' => $clothes, 'subTitle'=> 'Clothes - Index', 'busqueda' => $busqueda]);
    }
    
    
    function create(){
        return view('tienda.create');
    }
    
    
    function store(Request $request){
        if($archivo = $request->file('file')) {
            $nombre = $archivo->getClientOriginalName();
            $archivo->move('images', $nombre);
             $upload = new Image();
            $upload->file = $nombre;
            $upload->save();
             
            
        }
        return view('tienda.create');
    }
}
